#!/usr/bin/env python
#-- coding:utf-8 --

#=============================================
# 함께 사용되는 각종 파이썬 패키지들의 import 선언부
#=============================================
import pygame
import numpy as np
import math
import rospy
from xycar_msgs.msg import xycar_motor
import planning as pl

import draw as draw
import matplotlib.pyplot as plt

import time

#=============================================
# 모터 토픽을 발행할 것임을 선언
#============================================= 
motor_pub = rospy.Publisher('xycar_motor', xycar_motor, queue_size=1)
xycar_msg = xycar_motor()

#=============================================
# 프로그램에서 사용할 상수 선언부
#=============================================
AR = (1142, 62) # AR 태그의 위치
P_ENTRY = (1036, 162) # 주차라인 진입 시점의 좌표
P_END = (1129, 69) # 주차라인 끝의 좌표

#=============================================
# 모터 토픽을 발행하는 함수
# 입력으로 받은 angle과 speed 값을
# 모터 토픽에 옮겨 담은 후에 토픽을 발행함.
#=============================================
def drive(angle, speed):
    xycar_msg.angle = int(angle)
    xycar_msg.speed = int(speed)
    motor_pub.publish(xycar_msg)

#=============================================
# 경로를 생성하는 함수
# 차량의 시작위치 sx, sy, 시작각도 syaw
# 최대가속도 max_acceleration, 단위시간 dt 를 전달받고
# 경로를 리스트를 생성하여 반환한다.
#=============================================
# planning
rx, ry = [], []
ryaw, rdirect, path_x, path_y = [], [], [], []
flag = 1

def planning(sx, sy, syaw, max_acceleration, dt):
    global rx, ry, ryaw, rdirect, path_x, path_y

    global flag
    print("Start Planning")
    print("sx : ", sx, "sy : ", sy, "syaw : ", syaw, "max_acceleration : ", max_acceleration, "dt : ", dt)
    flag = 1
    states = [(sx, sy, syaw+90), (P_ENTRY[0], P_ENTRY[1], -45)]
    rx, ry, ryaw, rdirect, path_x, path_y = pl.generate_path(states)

    return path_x, path_y




#=============================================
# 생성된 경로를 따라가는 함수
# 파이게임 screen, 현재위치 x,y 현재각도, yaw
# 현재속도 velocity, 최대가속도 max_acceleration 단위시간 dt 를 전달받고
# 각도와 속도를 결정하여 주행한다.
#=============================================

node = pl.Node(0, 0, 0, 0, 0)
nodes = pl.Nodes()
ref_trajectory = pl.PATH(rx, ry)
target_ind = 0
cx, cy, cyaw, cdirect = [], [], [], []
x0, y0, yaw0, direct0 = 0, 0, 0, 0

t = 0.0
cnt = 0
flag2 = 1

def tracking(screen, x, y, yaw, velocity, max_acceleration, dt):
    global rx, ry, ryaw, rdirect, path_x, path_y

    global flag, flag2

    global maxTime, yaw_old
    global x0, y0, yaw0, direct0
    global x_rec, y_rec

    global cnt
    global t

    global node, nodes, ref_trajectory, target_ind
    global cx, cy, cyaw, cdirect
    global x_rec, y_rec 

    pl.C.dt = dt
    # print("x : ", x, "y : ", y, "yaw : ", yaw, "velocity : ", velocity, "max_acceleration : ", max_acceleration, "dt : ", dt)
    # print("Start Tracking")
    # main 
    # yaw = np.deg2rad(yaw)
    if flag :

        # maxTime = 100.0
        # yaw_old = 0.0
        # ryaw, rdirect, path_x, path_y = [], [], [], []
        # x_rec, y_rec = [], []
        # states = [(x, y, yaw), (P_ENTRY[0], P_ENTRY[1], -45)]

        # rx, ry, ryaw, rdirect, path_x, path_y = pl.generate_path(states)

        # simulation
        maxTime = 10000.0
        yaw_old = 0.0
        x0, y0, yaw0, direct0 = rx[0][0], ry[0][0], ryaw[0][0], rdirect[0][0]
        x_rec, y_rec = [], []
        flag = 0
        cnt = 0
        t = 0.0
        
    # 경로 및 방향 리스트
    # 왜 만들었냐면 경로가 여러개일 수 있으니까
    # 경로가 여러개일 때 각 경로의 목표 인덱스를 저장하기 위해서

    # 방향 전환 횟수
    turn_len = len(list(zip(rx, ry, rdirect)))
    # print("rx len : ", len(rx), "ry len : ", len(ry), "rdirect len : ", len(rdirect))
    # 경로가 존재할 때 경로 추종 시작  
    # 한번 실행되면 cnt가 변하기 전까지 실행되지 않음 
    if flag2 and cnt < turn_len:
        flag2 = 0
        print("cnt : ", cnt)
        cx, cy, cdirect = rx[cnt], ry[cnt], rdirect[cnt]
        # 현재 상태를 노드로 생성
        node = pl.Node(x=x0, y=y0, yaw=yaw0, v=0.0, direct=direct0)
        # 노드 리스트
        nodes = pl.Nodes()
        # 현재 상태를 노드 리스트에 추가
        nodes.add(t, node)
        # 경로 초기화
        ref_trajectory = pl.PATH(cx, cy)
        # 경로의 목표 인덱스 초기화
        target_ind, _ = ref_trajectory.target_index(node)

        # 경로 추종 시작
  
        # 방향에 따른 속도 및 제어값 설정
    if cnt < turn_len: 
        # node.x, node.y, node.yaw, node.direct = x, y, yaw, direct0
        # node.update(velocity, yaw, cdirect[0])
        # 전진
        if cdirect[0] > 0:
            # 목표 속도 설정
            target_speed = 30.0 
            # Ld : 전방 주행 차량과의 거리
            pl.C.Ld = 90.0 
            # 정지 거리
            pl.C.dist_stop = 20 
            # dc : 전방 주행 차량과의 거리 
            pl.C.dc = -8.4
        # 후진
        else:
            # 목표 속도 설정
            target_speed = 20.0 
            # Ld : 전방 주행 차량과의 거리
            pl.C.Ld = 70
            # 정지 거리
            pl.C.dist_stop = 10
            # dc : 전방 주행 차량과의 거리
            pl.C.dc = 1.68

        # 현재 상태를 노드 리스트에 추가
        
        # xt, yt : 전방 주행 차량의 위치
        # node.x = x
        # node.y = y
        # node.yaw = yaw
        xt = node.x + pl.C.dc * math.cos(node.yaw)
        yt = node.y + pl.C.dc * math.sin(node.yaw)
        # dist : 전방 주행 차량과의 거리
        dist = math.hypot(xt - cx[-1], yt - cy[-1])

        # 전방 주행 차량과의 거리가 정지 거리보다 작으면 정지
        if dist < pl.C.dist_stop:
            cnt += 1
            flag2 = 1
            print("다음 경로로 이동")
            drive(0, 0)
            return

        # 제어값 계산
        acceleration = pl.pid_control(target_speed, node.v, dist, cdirect[0])
        # delta : 차량의 조향각, target_ind : 경로의 목표 인덱스
        delta, target_ind = pl.pure_pursuit(node, ref_trajectory, target_ind)
        
        # 소수점 셋째 자리부턴 반올림 하여 버림 
        delta = math.floor(delta * 100) / 100
        # if delta > 0.2:
        #     delta = 0.2
        # if delta < -0.2:
        #     delta = -0.2
        
        
        # print("delta : ", delta, "acceleration : ", acceleration)
        # 시간 업데이트
        t += pl.C.dt
        # print("t : ", t)
        # 차량의 제어값 업데이트


        # node.x = x
        # node.y = y
        # node.yaw = np.deg2rad(yaw)
        # node.v = velocity
        print("yaw : ", node.yaw, "cdirect : ", cdirect[0])
        node.update(acceleration, delta, cdirect[0])
    
        node.v = 50 * cdirect[0]
        drive(delta*100, node.v)
        print("delta : ", delta, "node.v : ", node.v)
        # node.x = x
        # node.y = y
        # node.yaw =  np.deg2rad(yaw)
        # node.v = velocity

        # 노드 리스트에 제어값 업데이트
        nodes.add(t, node)
        # x_rec, y_rec : 차량이 지나온 경로
        x_rec.append(node.x)
        y_rec.append(node.y)


        # dy : 차량의 yaw 변화량
        dy = (node.yaw - yaw_old) / (node.v * dt)
        # steer : 차량의 조향각 (모형차량)
        steer = pl.rs.pi_2_pi(-math.atan(pl.C.WB * dy))
        # drive(steer*100, node.v)
        # drive(steer, acceleration)
        # print("steer : ", steer)
        # yaw_old : 이전 yaw 값 초기화
        yaw_old = node.yaw
        # x0, y0, yaw0, direct0 : 현재 상태 초기화
        x0 = nodes.x[-1]
        y0 = nodes.y[-1]
        yaw0 = nodes.yaw[-1]
        direct0 = nodes.direct[-1]
        # print("x0 : ", x0, "y0 : ", y0, "yaw0 : ", yaw0, "direct0 : ", direct0)


#        # 그래프 그리기
        plt.cla()
        
        plt.plot(node.x, node.y, marker='.', color='black')
        plt.plot(path_x, path_y, color='gray', linewidth=2)
        plt.plot(x_rec, y_rec, color='darkviolet', linewidth=2)
        # cx[target_ind], cy[target_ind] : 경로의 목표 인덱스
        plt.plot(cx[target_ind], cy[target_ind], ".r")
        draw.draw_car(node.x, node.y, yaw_old, steer, pl.C)

        plt.axis("equal")
        plt.title("PurePursuit: v=" + str(node.v)[:4] + "km/h")
        plt.gcf().canvas.mpl_connect('key_release_event',
                                        lambda event:
                                        [exit(0) if event.key == 'escape' else None])
        plt.pause(0.001)

plt.show()